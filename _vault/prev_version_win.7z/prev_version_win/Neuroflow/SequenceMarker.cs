﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Neuroflow
{
    public enum SequenceMarker : sbyte
    {
        Begin = -1,
        Inner = 0,
        End = 1
    }
}
