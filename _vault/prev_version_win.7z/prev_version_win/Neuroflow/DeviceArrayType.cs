﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Neuroflow
{
    public enum DeviceArrayType : byte
    {
        DeviceArray,
        DeviceArray2,
        DataArray
    }
}
