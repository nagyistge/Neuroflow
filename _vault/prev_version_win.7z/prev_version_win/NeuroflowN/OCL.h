#pragma once

#define __CL_ENABLE_EXCEPTIONS
#include <CL/cl.hpp>