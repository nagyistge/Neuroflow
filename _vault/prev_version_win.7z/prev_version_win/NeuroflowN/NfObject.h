#pragma once

#include "Typedefs.h"

namespace NeuroflowN
{
    class NfObject
    {
    public:
        virtual ~NfObject() { }
    };
}