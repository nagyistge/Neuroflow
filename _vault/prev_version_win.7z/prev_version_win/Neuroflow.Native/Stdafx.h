// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once

#include <vector>
#include <memory>
#include <msclr\marshal.h>
#include <msclr\marshal_cppstd.h>
#include <assert.h>
#include <functional>
#include <sstream>
