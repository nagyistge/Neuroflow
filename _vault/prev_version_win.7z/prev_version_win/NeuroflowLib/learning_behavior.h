#pragma once

#include "nfdev.h"
#include "layer_behavior.h"

namespace nf
{
    struct learning_behavior : virtual layer_behavior
    {
    };
}