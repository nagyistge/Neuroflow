#pragma once

#include "nfdev.h"

namespace nf
{
    struct layer_description : virtual nf_object
    {
    };
}