#pragma once

#include "nfdev.h"
#include "learning_behavior.h"

namespace nf
{
    struct learning_init_behavior : virtual learning_behavior
    {
    };
}