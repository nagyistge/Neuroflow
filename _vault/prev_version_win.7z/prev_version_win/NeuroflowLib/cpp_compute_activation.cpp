#include "stdafx.h"
#include "cpp_compute_activation.h"

USING

nf_object_ptr cpp_compute_activation::create_operation_context()
{
    return null;
}