#pragma once
#include <string>

namespace nf
{
    std::wstring version();
}