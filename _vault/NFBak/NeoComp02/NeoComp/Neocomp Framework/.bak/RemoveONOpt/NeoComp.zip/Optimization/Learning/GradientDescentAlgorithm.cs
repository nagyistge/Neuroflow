﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NeoComp.Networks.Computational.Neural;
using System.Diagnostics.Contracts;

namespace NeoComp.Optimization.Learning
{
    public sealed class GradientDescentAlgorithm : GradientDescentAlgorithm<GradientDescentRule> { }
    
    public class GradientDescentAlgorithm<T> : DeltaGradientLearningAlgorithm<T>
        where T : GradientDescentRule
    {
        protected virtual bool IsWeightUpdateAdaptive { get { return false; } }
        
        protected override void StochasticStep(bool isNewBatch, IBackwardConnection connection, T rule, Delta delta)
        {
            double update = GetStochasticWeightUpdate(isNewBatch, connection, rule, delta);
            UpdateWeight(connection, delta, update);
        }

        protected override void BatchStep(IBackwardConnection connection, T rule, Delta delta)
        {
            double update = GetBatchWeightUpdate(connection, rule, delta);
            UpdateWeight(connection, delta, update);
        }

        protected virtual double GetStochasticWeightUpdate(bool isNewBatch, IBackwardConnection connection, T rule, Delta delta)
        {
            Contract.Requires(connection != null);
            Contract.Requires(rule != null);
            Contract.Requires(delta != null);
            
            double stepSize = GetStepSize(true, connection, rule, delta);
            double update;
            if (IsWeightUpdateAdaptive)
            {
                update = stepSize;
            }
            else
            {
                update = stepSize * connection.BackwardValues.Last.Gradient;
            }

            double momentum = GetMomentum(true, connection, rule, delta);
            if (momentum != 0.0 && delta.LastUpdate.HasValue)
            {
                update = (momentum * delta.LastUpdate.Value) + update;// (update * (1.0 - momentum));
            }

            return update;
        }

        protected virtual double GetBatchWeightUpdate(IBackwardConnection connection, T rule, Delta delta)
        {
            Contract.Requires(connection != null);
            Contract.Requires(rule != null);
            Contract.Requires(delta != null); 
            
            double stepSize = GetStepSize(false, connection, rule, delta);
            double update;
            if (IsWeightUpdateAdaptive)
            {
                update = stepSize;
            }
            else
            {
                update = stepSize * connection.BackwardValues.AvgGradient;
            }

            double momentum = GetMomentum(false, connection, rule, delta);
            if (momentum != 0.0 && delta.LastUpdate.HasValue)
            {
                update = (momentum * delta.LastUpdate.Value) + update;
            }
            
            return update;
        }

        protected virtual double GetStepSize(bool isStochastic, IBackwardConnection connection, T rule, Delta delta)
        {
            Contract.Requires(connection != null);
            Contract.Requires(rule != null);
            Contract.Requires(delta != null);

            return rule.StepSize;
        }

        protected virtual double GetMomentum(bool isStochastic, IBackwardConnection connection, T rule, Delta delta)
        {
            Contract.Requires(connection != null);
            Contract.Requires(rule != null);
            Contract.Requires(delta != null);

            return rule.Momentum;
        }

        protected virtual void UpdateWeight(IBackwardConnection connection, Delta delta, double update)
        {
            Contract.Requires(connection != null);
            Contract.Requires(delta != null);

            connection.Weight += update;
            delta.LastUpdate = update;
        }
    }
}
