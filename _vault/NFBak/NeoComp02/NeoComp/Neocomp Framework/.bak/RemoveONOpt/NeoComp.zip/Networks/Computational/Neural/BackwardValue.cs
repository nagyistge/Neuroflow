﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics.Contracts;

namespace NeoComp.Networks.Computational.Neural
{
    public sealed class BackwardValue : IEquatable<BackwardValue>
    {
        double error, input, gradient;

        public double Error
        {
            get { return error; }
        }

        public double Input
        {
            get { return input; }
        }

        public double Gradient
        {
            get { return gradient; }
        }

        public bool Equals(BackwardValue other)
        {
            if (object.ReferenceEquals(other, null)) return false;
            return error == other.error && input == other.input && gradient == other.gradient;
        }

        public override bool Equals(object obj)
        {
            return obj is BackwardValue ? Equals((BackwardValue)obj) : false;
        }

        public override int GetHashCode()
        {
            return error.GetHashCode() ^ input.GetHashCode() ^ gradient.GetHashCode();
        }

        public override string ToString()
        {
            return string.Format("E: {0}, I: {1}, G: {2}", error, input, gradient);
        }

        public static bool operator ==(BackwardValue v1, BackwardValue v2)
        {
            if (object.ReferenceEquals(v1, null)) return object.ReferenceEquals(v2, null);
            return v1.Equals(v2);
        }

        public static bool operator !=(BackwardValue v1, BackwardValue v2)
        {
            if (object.ReferenceEquals(v1, null)) return !object.ReferenceEquals(v2, null);
            return !v1.Equals(v2);
        }

        internal void Add(double error, double input)
        {
            this.error += error;
            this.input += input;
            this.gradient += error * input;
        }

        internal void Set(double error, double input)
        {
            this.error = error;
            this.input = input;
            this.gradient = error * input;
        }
    }
}
