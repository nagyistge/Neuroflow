﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics.Contracts;
using NeoComp.Core;
using NeoComp.Computations;
using System.Runtime.Serialization;

namespace NeoComp.Networks.Computational
{
    [Serializable]
    [DataContract(IsReference = true, Namespace = NeoComp.xmlns)]
    public abstract class OperationNode<T> : ComputationalNode<T>
    {
        [DataMember(Name = "outValue", EmitDefaultValue = false)]
        ComputationalValue<T> outputValue;
        
        public T OutputValue
        {
            get { return outputValue == null ? default(T) : outputValue.Value; }
            private set
            {
                if (outputValue == null) outputValue = new ComputationalValue<T>();
                outputValue.Value = value;
            }
        }
        
        protected internal sealed override void Computation(ConnectionEntry<ComputationalConnection<T>>[] inputConnectionEntries, ConnectionEntry<ComputationalConnection<T>>[] outputConnectionEntries)
        {
            if (outputConnectionEntries.Length > 0)
            {
                T output;
                if (GenerateOutput(inputConnectionEntries, outputConnectionEntries, out output))
                {
                    OutputValue = output;
                }
            }
        }

        protected abstract bool GenerateOutput(ConnectionEntry<ComputationalConnection<T>>[] inputConnectionEntries, ConnectionEntry<ComputationalConnection<T>>[] outputConnectionEntries, out T output);

        internal void AdaptLowerConnection(ComputationalConnection<T> connection)
        {
            Contract.Requires(connection != null);

            connection.AdaptUpperOperationNode(this);
        }

        internal void AdaptValue(ComputationalValue<T> value)
        {
            Contract.Requires(value != null);

            outputValue = value;
        }
    }
}
