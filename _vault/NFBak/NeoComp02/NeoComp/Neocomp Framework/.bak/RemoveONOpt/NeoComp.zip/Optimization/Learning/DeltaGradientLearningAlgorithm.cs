﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NeoComp.Networks.Computational.Neural;
using System.Diagnostics.Contracts;
using NeoComp.Core;

namespace NeoComp.Optimization.Learning
{
    public class Delta
    {
        public double? LastUpdate { get; internal set; }
    }
    
    [ContractClass(typeof(DeltaGradientLearningAlgorithmContract<>))]
    public abstract class DeltaGradientLearningAlgorithm<T> : GradientLearningAlgorithm<T>
        where T : GradientRule
    {
        Delta[] deltaVector;

        protected ReadOnlyArray<Delta> DeltaVector { get; private set; }
        
        protected internal override void InitializeNewRun()
        {
            base.InitializeNewRun();

            if (deltaVector == null)
            {
                deltaVector = new Delta[LearningConnections.Count];
            }
            for (int idx = 0; idx < deltaVector.Length; idx++)
            {
                deltaVector[idx] = CreateDelta();
            }
            DeltaVector = ReadOnlyArray.Wrap(deltaVector);
        }

        protected virtual Delta CreateDelta()
        {
            return new Delta();
        }

        protected sealed override void StochasticStep(bool isNewBatch, IBackwardConnection connection, T rule, int connectionIndex)
        {
            StochasticStep(isNewBatch, connection, rule, deltaVector[connectionIndex]);
        }

        protected sealed override void StochasticEOF(IBackwardConnection connection, T rule, int connectionIndex)
        {
            StochasticEOF(connection, rule, deltaVector[connectionIndex]);
        }

        protected sealed override void BatchStep(IBackwardConnection connection, T rule, int connectionIndex)
        {
            BatchStep(connection, rule, deltaVector[connectionIndex]);
        }

        protected virtual void StochasticStep(bool isNewBatch, IBackwardConnection connection, T rule, Delta delta) { }

        protected virtual void StochasticEOF(IBackwardConnection connection, T rule, Delta delta) { }

        protected virtual void BatchStep(IBackwardConnection connection, T rule, Delta delta) { }
    }

    [ContractClassFor(typeof(DeltaGradientLearningAlgorithm<>))]
    abstract class DeltaGradientLearningAlgorithmContract<T> : DeltaGradientLearningAlgorithm<T>
        where T : GradientRule
    {
        // TODO: Enable this later.
        
        //protected override void StochasticStep(IBackwardConnection connection, T rule, Delta delta)
        //{
        //    Contract.Requires(connection != null);
        //    Contract.Requires(rule != null);
        //    Contract.Requires(delta != null);
        //}

        //protected override void StochasticEOF(IBackwardConnection connection, T rule, Delta delta)
        //{
        //    Contract.Requires(connection != null);
        //    Contract.Requires(rule != null);
        //    Contract.Requires(delta != null);
        //}

        //protected override void BatchStep(IBackwardConnection connection, T rule, Delta delta)
        //{
        //    Contract.Requires(connection != null);
        //    Contract.Requires(rule != null);
        //    Contract.Requires(delta != null);
        //}

        //protected override Delta CreateDelta()
        //{
        //    Contract.Ensures(Contract.Result<Delta>() != null);
        //    return null;
        //}
    }
}
