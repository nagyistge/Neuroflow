﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics.Contracts;

namespace NeoComp.Networks.Computational.Neural
{
    public class SpecializedActivationNeuron : ActivationNeuron
    {
        #region Constructors

        public SpecializedActivationNeuron(IActivationFunction activationFunction, object forwardParameters = null, object backwardParameters = null)
            : base(activationFunction)
        {
            Contract.Requires(activationFunction != null);

            ForwardParameters = forwardParameters;
            BackwardParameters = backwardParameters;
        }

        #endregion

        #region Properies

        public object ForwardParameters { get; set; }

        public object BackwardParameters { get; set; }

        #endregion
    }
}
