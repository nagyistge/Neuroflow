﻿using System;using System.Collections.Generic;
using System.Linq;
using System.Text;
using NeoComp.Networks.Computational.Neural;

namespace NeoComp.Optimization.Learning
{
    public sealed class RpropAlgorithm : LocalAdaptiveGDAlgorithm<RpropRule>
    {
        class RPDelta : LocalAdaptiveDelta
        {
            internal double RPUpdate { get; set; }
        }

        protected override Delta CreateDelta()
        {
            return new RPDelta();
        }
        
        protected override bool IsWeightUpdateAdaptive
        {
            get { return true; }
        }

        protected override void InitAdaptiveState(IBackwardConnection connection, RpropRule rule, LocalAdaptiveDelta delta, bool useAverageError)
        {
            var rpDelta = (RPDelta)delta;
            base.InitAdaptiveState(connection, rule, delta, useAverageError);
            rpDelta.RPUpdate = rule.StepSize;
        }

        protected override double CalculateCurrentStepSize(IBackwardConnection connection, RpropRule rule, LocalAdaptiveDelta delta, double signState, bool useAverageError)
        {
            double stepSize = 0.0;
            double error = delta.CurrentError;
            var rpDelta = (RPDelta)delta;

            if (signState >= 0)
            { 
                // no sign change

                if (signState > 0)
                {
                    rpDelta.RPUpdate *= rule.U;
                    if (rpDelta.RPUpdate > rule.StepSizeRange.MaxValue)
                    {
                        rpDelta.RPUpdate = rule.StepSizeRange.MaxValue;
                    }
                }

                // modify the weight
                if (error > 0)
                {
                    stepSize = rpDelta.RPUpdate;
                }
                else //if (error < 0)
                {
                    stepSize = -rpDelta.RPUpdate;
                }
            }
            else if (signState < 0)
            {
                // sign change
                rpDelta.RPUpdate *= rule.D;
                if (rpDelta.RPUpdate < rule.StepSizeRange.MinValue)
                {
                    rpDelta.RPUpdate = rule.StepSizeRange.MinValue;
                }
                rpDelta.CurrentError = 0;
                stepSize = 0;
            }

            return stepSize;
        }
    }
}
