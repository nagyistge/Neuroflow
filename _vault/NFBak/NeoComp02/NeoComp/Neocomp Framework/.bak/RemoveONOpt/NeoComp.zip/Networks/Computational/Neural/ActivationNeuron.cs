﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics.Contracts;
using NeoComp.Core;
using System.Runtime.Serialization;

namespace NeoComp.Networks.Computational.Neural
{
    [Serializable]
    [DataContract(IsReference = true, Namespace = NeoComp.xmlns, Name = "activNeuron")]
    public class ActivationNeuron : OperationNode<double>, IBackwardConnection, ILearningConnection, IBackwardPropagator
    {
        #region Constructors

        public ActivationNeuron(IActivationFunction activationFunction, params ILearningRule[] learningRules)
        {
            Contract.Requires(activationFunction != null);

            ActivationFunction = activationFunction;
            if (learningRules != null)
            {
                var fa = learningRules.ToArray();
                if (fa.Length != 0) this.learningRules = ReadOnlyArray.Wrap(fa);
            }
        }

        #endregion

        #region Properties

        [DataMember(Name = "bias")]
        public double Bias { get; set; }

        [DataMember(Name = "aFunc")]
        public IActivationFunction ActivationFunction { get; private set; }

        [NonSerialized]
        ReadOnlyArray<ILearningRule> learningRules;

        public ReadOnlyArray<ILearningRule> LearningRules
        {
            get { return learningRules; }
        }

        [NonSerialized]
        BackwardValues backwardValues = new BackwardValues();

        BackwardValues IBackwardConnection.BackwardValues
        {
            get { return backwardValues; }
        }

        IEnumerable<ILearningRule> ILearningConnection.LearningRules
        {
            get { return LearningRules; }
        }

        double INeuralConnection.InputValue
        {
            get { return 1.0; }
        }

        double INeuralConnection.Weight
        {
            get { return Bias; }
            set { Bias = value; }
        }

        #endregion

        #region Transfer

        protected sealed override bool GenerateOutput(ConnectionEntry<ComputationalConnection<double>>[] inputConnectionEntries, ConnectionEntry<ComputationalConnection<double>>[] outputConnectionEntries, out double output)
        {
            output = ActivationFunction.Function(Sum(inputConnectionEntries));
            return true;
        }

        private double Sum(ConnectionEntry<ComputationalConnection<double>>[] inputConnectionEntries)
        {
            double sum = Bias;
            foreach (var entry in inputConnectionEntries) sum += entry.Connection.OutputValue;
            return sum;
        }

        #endregion

        #region BackPropagate

        void IBackwardPropagator.BackPropagate(BackwardConnectionEntry[] outputs, BackwardConnectionEntry[] inputs, bool isNewBatch)
        {
            double error = 0.0;
            foreach (var output in outputs) error += output.Connection.BackwardValues.Last.Error * output.Connection.Weight;
            error *= ActivationFunction.Derivate(OutputValue);

            backwardValues.AddNext(error, 1.0, isNewBatch);
            foreach (var input in inputs) input.Connection.BackwardValues.AddNext(error, input.Connection.InputValue, isNewBatch);
        }

        #endregion
    }
}
