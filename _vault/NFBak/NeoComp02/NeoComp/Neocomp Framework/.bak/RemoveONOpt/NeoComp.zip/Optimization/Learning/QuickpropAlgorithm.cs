﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NeoComp.Networks.Computational.Neural;
using System.Diagnostics;

namespace NeoComp.Optimization.Learning
{
    public sealed class QuickpropAlgorithm : DeltaGradientLearningAlgorithm<QuickpropRule>
    {
        sealed class QuickPropDelta : Delta
        {
            public double? LastGradient { get; internal set; }
        }

        protected override Delta CreateDelta()
        {
            return new QuickPropDelta();
        }

        protected override void BatchStep(IBackwardConnection connection, QuickpropRule rule, Delta delta)
        {
            var qpDelta = (QuickPropDelta)delta;
            double gradient = connection.BackwardValues.AvgGradient;
            double update = GetWeightUpdate(rule, qpDelta, gradient);
            qpDelta.LastGradient = gradient;
            qpDelta.LastUpdate = update;
            connection.Weight += update;
        }

        private static double GetWeightUpdate(QuickpropRule rule, QuickPropDelta delta, double gradient)
        {
            double update = 0.0;

            if (!delta.LastUpdate.HasValue || delta.LastUpdate.Value == 0.0)
            {
                update = rule.StepSize * gradient;
            }
            else
            {
                double lastUpdate = delta.LastUpdate.Value;
                double lastGradient = delta.LastGradient.Value;
                double modeSwitchThreshold = rule.ModeSwitchThreshold;

                if (lastUpdate > modeSwitchThreshold)
                {
                    if (gradient > 0)
                    {
                        update = (rule.StepSize * gradient);
                    }

                    if (gradient > (rule.Shrink * lastGradient))
                    {
                        update += (rule.Mu * lastUpdate);
                    }
                    else
                    {
                        update += ((gradient / (lastGradient - gradient)) * lastUpdate);
                    }
                }
                else if (lastUpdate < (-1.0 * modeSwitchThreshold))
                {
                    if (gradient < 0)
                    {
                        update = (rule.StepSize * gradient);
                    }

                    if (gradient < (rule.Shrink * lastGradient))
                    {
                        update += (rule.Mu * lastUpdate);
                    }
                    else
                    {
                        update += ((gradient / (lastGradient - gradient)) * lastUpdate);
                    }
                }
                else
                {
                    update += (rule.StepSize * gradient) + (rule.Momentum * lastUpdate);
                }
            }

            return update;
        }
    }
}
