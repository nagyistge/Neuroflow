﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NeoComp
{
    public static class NeoComp
    {
        public const string xmlns = "http://neocomp.net";
    }
}
