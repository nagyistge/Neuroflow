﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NeoComp.Networks.Computational.Neural;
using NeoComp.Optimization.Algorithms.Quantum;
using NeoComp.Core;

namespace NeoComp.Optimization.Learning
{
    public sealed class MetaQSAAlgorithm : LocalAdaptiveGDAlgorithm<MetaQSARule>
    {
        const double qsaStrength = 1.0;
        const double qsaStabilize = 0.95;
        const double qsaDissolve = 0.001;
        
        internal class QSADelta : LocalAdaptiveDelta, IQuantumStatedItem
        {
            public QuantumStabilizerAlgorithm QSA { get; internal set; }
            
            public QuantumState State { get; set; }
        }

        protected override Delta CreateDelta()
        {
            return new QSADelta();
        }

        protected override void InitAdaptiveState(IBackwardConnection connection, MetaQSARule rule, LocalAdaptiveDelta delta, bool useAverageError)
        {
            base.InitAdaptiveState(connection, rule, delta, useAverageError);
            var qsaDelta = (QSADelta)delta;
            qsaDelta.State = rule.StepSizeRange.Normalize(qsaDelta.CurrentStepSize, new DoubleRange(0.0, 1.0));
            qsaDelta.QSA = new QuantumStabilizerAlgorithm(qsaDelta, qsaStrength);
            qsaDelta.CurrentStepSize = ToStepSize(qsaDelta.State, rule.StepSizeRange);
        }

        protected override double CalculateCurrentStepSize(IBackwardConnection connection, MetaQSARule rule, LocalAdaptiveDelta delta, double signState, bool useAverageError)
        {
            var qsaDelta = (QSADelta)delta;
            if (signState > 0.0)
            {
                // Stable.
                qsaDelta.QSA.Stabilize(qsaStabilize);
            }
            else if (signState < 0.0)
            {
                // Gone wrong.
                qsaDelta.QSA.Dissolve(qsaDissolve);
            }
            return ToStepSize(qsaDelta.State, rule.StepSizeRange);
        }

        private static double ToStepSize(QuantumState quantumState, DoubleRange ssRange)
        {
            double ss = new DoubleRange(0.0, 1.0).Normalize(quantumState, ssRange);
            return ss;
        }
    }
}
