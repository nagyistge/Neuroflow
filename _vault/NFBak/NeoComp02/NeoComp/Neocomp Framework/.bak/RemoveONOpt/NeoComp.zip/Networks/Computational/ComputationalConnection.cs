﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NeoComp.Core;
using System.Diagnostics.Contracts;
using NeoComp.Computations;
using System.Diagnostics;
using System.Runtime.Serialization;

namespace NeoComp.Networks.Computational
{
    [Serializable]
    [DataContract(IsReference = true, Namespace = NeoComp.xmlns)]
    public abstract class ComputationalConnection<T>
    {
        [DataMember(Name = "value", EmitDefaultValue = false)]
        ComputationalValue<T> connectionValue;

        [DataMember(Name = "opNodeRef", EmitDefaultValue = false)]
        OperationNode<T> operationNode;

        public T InputValue
        {
            get
            {
                if (operationNode != null) return operationNode.OutputValue;
                if (connectionValue != null) return connectionValue.Value;
                return default(T);
            }
        }

        public virtual T OutputValue
        {
            get { return InputValue; }
        }

        internal void SetupInputValue(T value)
        {
            if (operationNode != null)
            {
                if (connectionValue == null) connectionValue = new ComputationalValue<T>();
                connectionValue.Value = value;
            }
#if DEBUG
            else
            {
                Debug.Fail(this.ToString() + " is read only.");
            }
#endif
        }

        internal void AdaptUpperOperationNode(OperationNode<T> node)
        {
            Contract.Requires(node != null);

            operationNode = node;
            connectionValue = null;
        }

        internal void AdaptValue(ComputationalValue<T> value)
        {
            Contract.Requires(value != null);

            if (operationNode != null)
            {
                operationNode.AdaptValue(value);
            }
            else
            {
                connectionValue = value;
            }
        }
    }
}
