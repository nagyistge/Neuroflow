﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NeoComp.Networks.Computational.Neural;
using System.Diagnostics.Contracts;

namespace NeoComp.Optimization.Learning
{
    public class LocalAdaptiveDelta : Delta
    {
        public bool HasAdaptiveState { get; internal set; }
        
        public double LastError { get; internal set; }

        public double CurrentError { get; internal set; }

        public double CurrentStepSize { get; internal set; }
    }

    [ContractClass(typeof(LocalAdaptiveGDAlgorithmContract<>))]
    public abstract class LocalAdaptiveGDAlgorithm<T> : GradientDescentAlgorithm<T>
        where T : LocalAdaptiveGDRule
    {
        protected override void StochasticStep(bool isNewBatch, IBackwardConnection connection, T rule, Delta delta)
        {
            if (rule.StochasticAdaptiveStateUpdate) StepAdaptiveState(connection, rule, (LocalAdaptiveDelta)delta, false);
            base.StochasticStep(isNewBatch, connection, rule, delta);
        }
        
        protected override void StochasticEOF(IBackwardConnection connection, T rule, Delta delta)
        {
            if (!rule.StochasticAdaptiveStateUpdate) StepAdaptiveState(connection, rule, (LocalAdaptiveDelta)delta, true);
        }

        protected override void BatchStep(IBackwardConnection connection, T rule, Delta delta)
        {
            StepAdaptiveState(connection, rule, (LocalAdaptiveDelta)delta, true);
            base.BatchStep(connection, rule, delta);
        }

        private void StepAdaptiveState(IBackwardConnection connection, T rule, LocalAdaptiveDelta delta, bool useAverageError)
        {
            if (!delta.HasAdaptiveState)
            {
                InitAdaptiveState(connection, rule, delta, useAverageError);
                delta.HasAdaptiveState = true;
            }
            else
            {
                UpdateAdaptiveState(connection, rule, delta, useAverageError);
                double signState = delta.CurrentError * delta.LastError;
                double ss = CalculateCurrentStepSize(connection, rule, delta, signState, useAverageError);
                if (!IsWeightUpdateAdaptive) delta.CurrentStepSize = rule.StepSizeRange.Cut(ss); else delta.CurrentStepSize = ss;
            }
        }

        protected virtual void UpdateAdaptiveState(IBackwardConnection connection, T rule, LocalAdaptiveDelta delta, bool useAverageError)
        {
            double error = useAverageError ? connection.BackwardValues.AvgError : connection.BackwardValues.Last.Error;
            delta.LastError = delta.CurrentError;
            delta.CurrentError = error;
        }

        protected virtual void InitAdaptiveState(IBackwardConnection connection, T rule, LocalAdaptiveDelta delta, bool useAverageError)
        {
            double error = useAverageError ? connection.BackwardValues.AvgError : connection.BackwardValues.Last.Error;
            delta.LastError = delta.CurrentError = error;
            delta.CurrentStepSize = rule.StepSize;
        }

        protected abstract double CalculateCurrentStepSize(IBackwardConnection connection, T rule, LocalAdaptiveDelta delta, double signState, bool useAverageError);

        protected override double GetStepSize(bool isStochastic, IBackwardConnection connection, T rule, Delta delta)
        {
            var ad = (LocalAdaptiveDelta)delta;
            return ad.HasAdaptiveState ? ad.CurrentStepSize : rule.StepSize;
        }
        
        protected override Delta CreateDelta()
        {
            return new LocalAdaptiveDelta();
        }
    }

    [ContractClassFor(typeof(LocalAdaptiveGDAlgorithm<>))]
    abstract class LocalAdaptiveGDAlgorithmContract<T> : LocalAdaptiveGDAlgorithm<T>
        where T : LocalAdaptiveGDRule
    {
        // TODO: Enable this later.
        
        //protected override double CalculateCurrentStepSize(bool isStochastic, IBackwardConnection connection, T rule, LocalAdaptiveDelta delta, double signState)
        //{
        //    Contract.Requires(connection != null);
        //    Contract.Requires(rule != null);
        //    Contract.Requires(delta != null);
        //    return 0.0;
        //}

        //protected override void UpdateAdaptiveState(bool isStochastic, IBackwardConnection connection, T rule, LocalAdaptiveDelta delta)
        //{
        //    Contract.Requires(connection != null);
        //    Contract.Requires(rule != null);
        //    Contract.Requires(delta != null);
        //}

        //protected override void InitAdaptiveState(bool isStochastic, IBackwardConnection connection, T rule, LocalAdaptiveDelta delta)
        //{
        //    Contract.Requires(connection != null);
        //    Contract.Requires(rule != null);
        //    Contract.Requires(delta != null);
        //}
    }
}
