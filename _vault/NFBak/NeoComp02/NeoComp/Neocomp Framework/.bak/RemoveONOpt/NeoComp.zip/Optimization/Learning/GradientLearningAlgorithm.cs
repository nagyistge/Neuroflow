﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NeoComp.Networks.Computational.Neural;
using System.Diagnostics.Contracts;

namespace NeoComp.Optimization.Learning
{
    [ContractClass(typeof(GradientLearningAlgorithmContract<>))]
    public abstract class GradientLearningAlgorithm<T> : BackwardLearningAlgorithm
        where T : GradientRule
    {
        bool isNewBatch;
        
        protected internal override void BackwardIteration(bool batch, double mse)
        {
            base.BackwardIteration(batch, mse);

            var lca = LearningConnections.ItemArray;
            for (int idx = 0; idx < lca.Length; idx++)
            {
                var lc = lca[idx];
                var rule = (T)lc.Rule;
                var conn = (IBackwardConnection)lc.Connection;
                var mode = rule.GetMode();

                if (mode == LearningMode.Stochastic)
                {
                    StochasticStep(isNewBatch, conn, rule, idx);
                    isNewBatch = false;
                }
                
                if (batch)
                {
                    if (mode == LearningMode.Batch)
                    {
                        BatchStep(conn, rule, idx);
                    }
                    else
                    {
                        StochasticEOF(conn, rule, idx);
                    }
                    isNewBatch = true;
                }
            }
        }

        protected internal override void InitializeNewRun()
        {
            base.InitializeNewRun();
            isNewBatch = true;
        }

        protected virtual void StochasticStep(bool isNewBatch, IBackwardConnection connection, T rule, int connectionIndex) { }

        protected virtual void StochasticEOF(IBackwardConnection connection, T rule, int connectionIndex) { }

        protected virtual void BatchStep(IBackwardConnection connection, T rule, int connectionIndex) { }
    }

    [ContractClassFor(typeof(GradientLearningAlgorithm<>))]
    abstract class GradientLearningAlgorithmContract<T> : GradientLearningAlgorithm<T>
        where T : GradientRule
    {
        protected override void BatchStep(IBackwardConnection connection, T rule, int connectionIndex)
        {
            Contract.Requires(connection != null);
            Contract.Requires(rule != null);
            Contract.Requires(connectionIndex >= 0 && connectionIndex < LearningConnections.Count);
        }

        protected override void StochasticStep(bool isNewBatch, IBackwardConnection connection, T rule, int connectionIndex)
        {
            Contract.Requires(connection != null);
            Contract.Requires(rule != null);
            Contract.Requires(connectionIndex >= 0 && connectionIndex < LearningConnections.Count);
        }

        protected override void StochasticEOF(IBackwardConnection connection, T rule, int connectionIndex)
        {
            Contract.Requires(connection != null);
            Contract.Requires(rule != null);
            Contract.Requires(connectionIndex >= 0 && connectionIndex < LearningConnections.Count);
        }
    }
}
