﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NeoComp.Networks.Computational.Neural
{
    public class SpecializedSynapse : Synapse
    {
        #region Contructor

        public SpecializedSynapse(object forwardParameters = null, object backwardParameters = null)
        {
            ForwardParameters = forwardParameters;
            BackwardParameters = backwardParameters;
        }

        #endregion

        #region Properies

        public object ForwardParameters { get; set; }

        public object BackwardParameters { get; set; }

        #endregion
    }
}
