﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NeoComp.Evolution.GA;
using System.Diagnostics.Contracts;
using NeoComp.Core;

namespace NeoComp.Networks.Computational.Logical.GA
{
    public enum GateTypeEvolutionMethod : byte { Restrict = 0, Evolve = 1 }
    
    public class LogicalNetworkEntityFactory : NaturalEntityFactory<LogicalGene>
    {
        static readonly LogicalOperation[] AllOps = new[] { LogicalOperation.AND, LogicalOperation.NAND, LogicalOperation.NOR, LogicalOperation.OR, LogicalOperation.XNOR, LogicalOperation.XOR };
        
        #region Contruct

        public LogicalNetworkEntityFactory(TruthTable truthTableToSolve, LogicGateTypes gateTypeRestrictions = null)
        {
            Contract.Requires(truthTableToSolve != null);

            TruthTableToSolve = truthTableToSolve;
            GateTypeRestrictions = gateTypeRestrictions;

            if (gateTypeRestrictions != null)
            {
                allowedOperations = gateTypeRestrictions.Operations.ToArray();
            }
            else
            {
                allowedOperations = AllOps;
            }
        }

        #endregion

        #region Props and Fields

        LogicalOperation[] allowedOperations;

        public TruthTable TruthTableToSolve { get; private set; }

        public LogicGateTypes GateTypeRestrictions { get; private set; }

        public GateTypeEvolutionMethod GateTypeEvolutionMethod { get; set; } 

        IntRange allowedConnectionIndexRange = IntRange.CreateExclusive(0, 100);

        public IntRange AllowedConnectionIndexRange
        {
            get { return allowedConnectionIndexRange; }
            set
            {
                Contract.Requires(value.MinValue >= 0);

                allowedConnectionIndexRange = value;
            }
        }

        public bool CreateRecurrentNetworks { get; private set; }

        #endregion

        #region Init

        protected override void FillInitialRandomGeneSequence(LogicalGene[] sequence)
        {
            for (int idx = 0; idx < sequence.Length; idx++)
            {
                sequence[idx] = CreateRandomGene();
            }
        }

        #endregion

        #region Offspring

        protected override LogicalGene GetMutatedVersion(LogicalGene gene)
        {
            var gg = (LogicGateGene)gene;
            var ci = gg.ConnectionIndex;
            var op = gg.Operation;
            if (RandomGenerator.FiftyPercentChance)
            {
                return new LogicGateGene(ci, CreateRandomOp());
            }
            else
            {
                return new LogicGateGene(CreateRandomConnIndex(), op);
            }
        }

        #endregion

        #region LN Entity Create

        protected override Entity<DNA<LogicalGene>> CreateEntityInstance(DNA<LogicalGene> dna, IEnumerable<LogicalGene> dominantGeneSequence)
        {
            LogicalNetworkFactory factory;
            if (GateTypeEvolutionMethod == GateTypeEvolutionMethod.Restrict)
            {
                factory = new LogicalNetworkFactory(TruthTableToSolve.InputInterfaceLength, TruthTableToSolve.OutputInterfaceLength, GateTypeRestrictions);
            }
            else // Evolve
            {
                factory = new LogicalNetworkFactory(TruthTableToSolve.InputInterfaceLength, TruthTableToSolve.OutputInterfaceLength);
            }

            var connF = new Factory<LogicalConnection>();
            foreach (var gene in dominantGeneSequence)
            {
                var node = gene.CreateNode();
                if (node != null)
                {
                    factory.TryAddNodeFactory(gene.ConnectionIndex.LowerNodeIndex, new Factory<ComputationalNode<bool>>(() => node));
                }
                factory.TryAddConnectionFactory(gene.ConnectionIndex, connF);
            }

            var network = new LogicalNetwork(factory);

            int numOfNAGates = 0;
            if (GateTypeEvolutionMethod == GateTypeEvolutionMethod.Evolve && GateTypeRestrictions != null)
            {
                foreach (var entry in network.EntryArray)
                {
                    var gate = entry.NodeEntry.Node as LogicGate;
                    if (gate != null)
                    {
                        var type = new LogicGateType(gate.Operation, entry.UpperConnectionEntryArray.Length);
                        if (!GateTypeRestrictions.Contains(type)) numOfNAGates++;
                    }
                }
            }

            int errors = new TruthTableComputation(network).ComputeError(TruthTableToSolve);

            return new LogicalNetworEntity(dna, network, errors, numOfNAGates);
        }

        #endregion

        #region Helpers

        protected virtual LogicalGene CreateRandomGene()
        {
            return new LogicGateGene(CreateRandomConnIndex(), CreateRandomOp());
        }

        private LogicalOperation? CreateRandomOp()
        {
            if (RandomGenerator.FiftyPercentChance) return null;
             
            if (GateTypeEvolutionMethod == GA.GateTypeEvolutionMethod.Restrict)
            {
                return allowedOperations[RandomGenerator.Random.Next(allowedOperations.Length)];
            }
            else
            {
                return AllOps[RandomGenerator.Random.Next(AllOps.Length)];
            }
        }

        private ConnectionIndex CreateRandomConnIndex()
        {
            ConnectionIndex index;
            do
            {
                index = new ConnectionIndex(AllowedConnectionIndexRange.PickRandomValue(), AllowedConnectionIndexRange.PickRandomValue());
            }
            while (!IsValidConnIndex(index));
            return index;
        }

        private bool IsValidConnIndex(ConnectionIndex index)
        {
            if (!CreateRecurrentNetworks && index.LowerNodeIndex <= index.UpperNodeIndex) return false;
            return true;
        }

        #endregion
    }
}
