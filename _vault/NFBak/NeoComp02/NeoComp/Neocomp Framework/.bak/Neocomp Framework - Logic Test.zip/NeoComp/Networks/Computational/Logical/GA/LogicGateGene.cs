﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics.Contracts;

namespace NeoComp.Networks.Computational.Logical.GA
{
    public sealed class LogicGateGene : LogicalNodeGene
    {
        public LogicGateGene(int index, LogicalOperation operation)
            : base(index)
        {
            Contract.Requires(index > 0); 
            
            Operation = operation;
        }
        
        public LogicalOperation Operation { get; private set; }

        protected internal override ComputationalNode<bool> CreateNode()
        {
            return new LogicGate(Operation);
        }
    }
}
