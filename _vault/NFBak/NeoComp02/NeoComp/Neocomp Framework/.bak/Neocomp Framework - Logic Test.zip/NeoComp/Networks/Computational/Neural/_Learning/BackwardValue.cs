﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics.Contracts;
using NeoComp.Computations;

namespace NeoComp.Networks.Computational.Neural
{
    public sealed class BackwardValue
    {
        public double Error { get; private set; }

        public double Gradient { get; private set; }
        
        public override string ToString()
        {
            return string.Format("E: {0}, G: {1}", Error, Gradient);
        }

        internal void Add(double error, double input)
        {
            Error = error;
            Gradient += error * input;
        }

        internal void Set(double error)
        {
            Error = error;
            Gradient = 0.0;
        }

        internal void Set(double error, double input)
        {
            Error = error;
            Gradient = error * input;
        }

        internal void Reset()
        {
            Error = 0;
            Gradient = 0;
        }
    }
}
