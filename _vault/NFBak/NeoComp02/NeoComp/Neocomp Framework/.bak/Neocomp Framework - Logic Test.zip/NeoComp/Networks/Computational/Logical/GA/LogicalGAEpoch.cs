﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NeoComp.Evolution.GA;
using System.Diagnostics.Contracts;

namespace NeoComp.Networks.Computational.Logical.GA
{
    public sealed class LogicalGAEpoch : GAEpoch<DNA<LogicalNetworkGene>>
    {
        #region Contruct

        public LogicalGAEpoch(LogicalNetworkEntityFactory entityFactory, int numberOfPopulations, int populationSize)
            : base(entityFactory, numberOfPopulations, populationSize)
        {
            Contract.Requires(entityFactory != null);
            Contract.Requires(numberOfPopulations > 0);
            Contract.Requires(populationSize > 0);
        }

        #endregion
    }
}
