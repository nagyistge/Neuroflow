﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NeoComp.Networks.Computational.Neural
{
    public class ActivationNeuronBackpropagator : Backpropagator
    {
        internal ActivationNeuronBackpropagator(ActivationNeuron neuron)
            : base(neuron)
        {
            Neuron = neuron;
            biasConn = (IBackwardConnection)neuron;
        }

        public ActivationNeuron Neuron { get; private set; }

        IBackwardConnection biasConn;

        Queue<double> outputDerivates;

        double[] inputSums;

        double errorSum;

        int errorCount;

        protected internal override void TrackForwardInformation()
        {
            //Recurrent mode init:
            if (outputDerivates == null)
            {
                outputDerivates = new Queue<double>();
                inputSums = new double[InputConnectionEntries.ItemArray.Length];
            }

            // Track info:
            outputDerivates.Enqueue(Neuron.ActivationFunction.Derivate(Neuron.OutputValue.Value));
            for (int idx = 0; idx < inputSums.Length; idx++) inputSums[idx] += InputConnectionEntries.ItemArray[idx].Connection.InputValue;
        }

        protected internal override void Backpropagate()
        {
            double currError = GetCurrentError();

            if (outputDerivates == null)
            {
                // Feed forward:
                biasConn.BackwardValues.AddNext(currError, 1.0);
                foreach (var inputConnEntry in InputConnectionEntries.ItemArray)
                {
                    inputConnEntry.Connection.BackwardValues.AddNext(currError, inputConnEntry.Connection.InputValue);
                }
            }
            else
            {
                // Recurrent:
                bool isLastError = outputDerivates.Count == 0;

                // Store error:
                errorSum += currError;
                errorCount++;

                if (isLastError)
                {
                    double dErrorCount = (double)errorCount;

                    currError = errorSum / dErrorCount;

                    biasConn.BackwardValues.AddNext(currError, 1.0);
                    for (int idx = 0; idx < inputSums.Length; idx++)
                    {
                        var inputConnEntry = InputConnectionEntries.ItemArray[idx];

                        inputConnEntry.Connection.BackwardValues.AddNext(currError, inputSums[idx] / dErrorCount);

                        inputSums[idx] = 0.0;
                    }

                    // Reset error sum:
                    errorSum = 0.0;
                    errorCount = 0;
                }
                else
                {
                    SetErrorToInputs(currError);
                }
            }
        }

        private void SetErrorToInputs(double error)
        {
            foreach (var inputConnEntry in InputConnectionEntries.ItemArray)
            {
                inputConnEntry.Connection.BackwardValues.SetError(error);
            }
        }

        private double GetCurrentError()
        {
            double error = 0.0;
            foreach (var outputConnEntry in OutputConnectionEntries.ItemArray)
            {
                error += outputConnEntry.Connection.Weight * outputConnEntry.Connection.BackwardValues.Last.Error;
            }
            error *= GetCurrentOutputValueDerivate();
            return error;
        }

        private double GetCurrentOutputValueDerivate()
        {
            if (outputDerivates == null) return Neuron.ActivationFunction.Derivate(Neuron.OutputValue.Value);
            try
            {
                return outputDerivates.Dequeue();
            }
            catch (InvalidOperationException)
            {
                throw new InvalidOperationException("Internal backpropagation logic error. ActivationNeuron's outputValueDerivateStack is empty.");
            }
        }
    }
}
