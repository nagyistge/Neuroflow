﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics.Contracts;

namespace NeoComp.Networks.Computational.Logical.GA
{
    [ContractClass(typeof(LogicalGeneContract))]
    public abstract class LogicalGene
    {
        protected LogicalGene(ConnectionIndex connectionIndex)
        {
            ConnectionIndex = connectionIndex;
        }
        
        public ConnectionIndex ConnectionIndex { get; private set; }

        protected internal abstract ComputationalNode<bool> CreateNode();
    }

    [ContractClassFor(typeof(LogicalGene))]
    abstract class LogicalGeneContract : LogicalGene
    {
        LogicalGeneContract() : base(default(ConnectionIndex)) { }
        
        protected internal override ComputationalNode<bool> CreateNode()
        {
            return null;
        }
    }
}
