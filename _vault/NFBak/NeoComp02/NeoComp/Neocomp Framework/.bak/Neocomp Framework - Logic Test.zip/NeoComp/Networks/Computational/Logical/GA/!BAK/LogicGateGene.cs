﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NeoComp.Networks.Computational.Logical.GA
{
    public class LogicGateGene : LogicalGene
    {
        public LogicGateGene(ConnectionIndex connectionIndex, LogicalOperation? operation)
            : base(connectionIndex)
        {
            Operation = operation;
        }

        public LogicalOperation? Operation { get; private set; }

        protected internal override ComputationalNode<bool> CreateNode()
        {
            return Operation != null ? new LogicGate(Operation.Value) : null;
        }
    }
}
