﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Linq.Expressions;
using System.Diagnostics.Contracts;

namespace ComputationAPI
{
    public sealed class ComputationValue<T>
        where T : struct
    {
        internal ComputationValue(ComputationValueBuffer<T> buffer, int index)
        {
            this.buffer = buffer;
            this.index = index;
        }

        private ComputationValueBuffer<T> buffer;

        private int index;

        public T Value { get; set; }

        public T Value2
        {
            get { return buffer.Buffer[index]; }
            set { buffer.Buffer[index] = value; }
        }

        public Expression ValueExpression
        {
            get
            {
                var idxEx = Expression.Constant(index);
                var arrEx = Expression.Constant(buffer.Buffer);
                return Expression.ArrayAccess(arrEx, idxEx);
            }
        }

        public Expression Assign(Expression value)
        {
            Contract.Requires(value != null);

            return Expression.Assign(ValueExpression, value);
        }
    }
}
