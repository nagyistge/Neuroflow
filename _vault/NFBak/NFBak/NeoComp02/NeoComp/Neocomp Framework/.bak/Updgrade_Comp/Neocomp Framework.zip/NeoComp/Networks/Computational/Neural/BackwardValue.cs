﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics.Contracts;

namespace NeoComp.Networks.Computational.Neural
{
    public sealed class BackwardValue
    {
        double error, input, gradient;

        public double Error
        {
            get { return error; }
        }

        public double Input
        {
            get { return input; }
        }

        public double Gradient
        {
            get { return gradient; }
        }
        
        public override string ToString()
        {
            return string.Format("E: {0}, I: {1}, G: {2}", error, input, gradient);
        }

        internal void Add(double error, double input)
        {
            this.error += error;
            this.input += input;
            this.gradient += error * input;
        }

        internal void Set(double error, double input)
        {
            this.error = error;
            this.input = input;
            this.gradient = error * input;
        }
    }
}
