﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NeoComp.Core;
using System.Diagnostics.Contracts;
using System.IO;
using System.Drawing;
using NeoComp.Features;

namespace ImgNoise.Features
{
    internal static class Search
    {
        #region Region

        internal static IEnumerable<NoisedImagePartReader> FindReaders(SearchingParams searchingPars, SamplingParams samplingPars)
        {
            Contract.Requires(!searchingPars.IsEmpty);
            Contract.Requires(!samplingPars.IsEmpty);
            Contract.Ensures(Contract.Result<IEnumerable<NoisedImagePartReader>>() != null);

            return SearchForNIPs(samplingPars, SearchForFiles(searchingPars));
        } 

        #endregion

        #region To NIP

        private static IEnumerable<NoisedImagePartReader> SearchForNIPs(SamplingParams samplingPars, IEnumerable<FileInfo> files)
        {
            double noise = 0.0;
            int sampleIndex = 0;
            foreach (var file in files)
            {
                int size = samplingPars.Size;
                var imgSize = GetImageSize(file);
                if (imgSize != null && imgSize.Value.Width >= size && imgSize.Value.Height >= size)
                {
                    // Supported and fits.
                    string fileName = file.FullName;
                    for (int y = 0; y < imgSize.Value.Height - size; y += size)
                    {
                        for (int x = 0; x < imgSize.Value.Width - size; x += size)
                        {
                            if ((sampleIndex++ % samplingPars.Frequency) == 0)
                            {
                                var p = new Point(x, y);
                                yield return new NoisedImagePartReader(fileName, p, size, Channel.Red, noise);
                                yield return new NoisedImagePartReader(fileName, p, size, Channel.Green, noise);
                                yield return new NoisedImagePartReader(fileName, p, size, Channel.Blue, noise);
                                noise += 0.001;
                                if (Math.Round(noise, 5) > NIPData.MaxNoiseLevel) noise = 0.0;
                            }
                        }
                    }
                }
            }
        }

        private static Size? GetImageSize(FileInfo file)
        {
            try
            {
                var img = Image.FromFile(file.FullName);
                return new Size(img.Width, img.Height);
            }
            catch
            {
                return null; // Not supported format.
            }
        }

        #endregion

        #region File Search

        private static IEnumerable<FileInfo> SearchForFiles(SearchingParams searchingPars)
        {
            var visited = new HashSet<string>();
            return SearchForFiles(searchingPars.Directories.Select(d => new DirectoryInfo(d)).Where(di => di.Exists), searchingPars.Filters, searchingPars.Recursive, visited);
        }

        private static IEnumerable<FileInfo> SearchForFiles(IEnumerable<DirectoryInfo> directories, Strings filters, bool recursive, HashSet<string> visited)
        {
            foreach (var di in directories)
            {
                if (!visited.Contains(di.FullName))
                {
                    foreach (string filter in filters)
                    {
                        foreach (var fi in di.GetFiles(filter))
                        {
                            yield return fi;
                        }
                    }

                    if (recursive)
                    {
                        var sdirs = di.GetDirectories();
                        if (sdirs.Length > 0)
                        {
                            foreach (var sfi in SearchForFiles(sdirs, filters, recursive, visited))
                            {
                                yield return sfi;
                            }
                        }
                    }

                    visited.Add(di.Name);
                }
            }
        } 

        #endregion
    }
}
