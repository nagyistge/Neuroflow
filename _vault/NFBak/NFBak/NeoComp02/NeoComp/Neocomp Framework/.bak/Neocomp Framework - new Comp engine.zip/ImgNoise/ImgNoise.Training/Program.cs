﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ImgNoise.Features;
using NeoComp.Learning;

namespace ImgNoise.Training
{
    internal static class Program
    {
        static void Main()
        {
            try
            {
                Begin();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.GetType().Name);
                Console.WriteLine(ex.Message);
            }
            Console.WriteLine("Press any key to exit ...");
            Console.ReadKey();
        }

        private static void Begin()
        {
            var trainingProv = CreateProvider(1000);
            var trainingStrat = new MonteCarloBatchingStrategy();
            var trainingBatcher = new LearningScriptCollectionBatcher(trainingStrat, trainingProv, 100);

            var validProv = CreateProvider(100);
            var validStrat = new MonteCarloBatchingStrategy();
            var validBatcher = new LearningScriptCollectionBatcher(validStrat, validProv, 10);

            trainingBatcher.Initialize();
            validBatcher.Initialize();

            var next1 = trainingBatcher.GetNext();
            var next2 = trainingBatcher.GetNext();
            var next3 = validBatcher.GetNext();
            var next4 = validBatcher.GetNext();
        }

        static LearningScriptCollectionProvider CreateProvider(int sampleCount)
        {
            string debugPath = @"C:\Users\unbornchikken\Pictures\NN\HQ_Parts\";
            
            //var searchPars = new SearchingParams(Properties.Settings.Default.ImagePaths.Split(';'), new[] { "*.jpg", "*.png" }, true);
            var searchPars = new SearchingParams(debugPath, new[] { "*.jpg", "*.png" }, true);
            var samplPars = new SamplingParams(Properties.Settings.Default.SampleSize);
            var prov = new NIPFFLearningScriptProvider(searchPars, samplPars, sampleCount);
            return prov;
        }
    }
}
