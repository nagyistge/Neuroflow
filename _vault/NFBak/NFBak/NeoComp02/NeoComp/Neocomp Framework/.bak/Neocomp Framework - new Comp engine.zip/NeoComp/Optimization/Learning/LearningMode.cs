﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NeoComp.Optimization.Learning
{
    public enum LearningMode : byte { Stochastic = 0, Batch = 1 }
}
