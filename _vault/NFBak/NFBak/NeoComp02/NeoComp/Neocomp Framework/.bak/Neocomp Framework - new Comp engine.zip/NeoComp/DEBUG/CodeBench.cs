﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Diagnostics.Contracts;

namespace NeoComp.DEBUG
{
    public sealed class CodeBench
    {
        static CodeBench() { }
        
        static Dictionary<string, CodeBench> cbDict = new Dictionary<string, CodeBench>();

        public static CodeBench Named(string id)
        {
            Contract.Requires(!String.IsNullOrEmpty(id));

            CodeBench cb;
            lock (cbDict)
            {
                if (!cbDict.TryGetValue(id, out cb))
                {
                    cb = new CodeBench(id);
                    cbDict.Add(id, cb);
                }
                return cb;
            }
        }
        
        internal CodeBench(string id)
        {
            Contract.Requires(!String.IsNullOrEmpty(id));
            
            this.id = id;
        }
        
        string id;
        
        int count;

        double totalMS, lastMS;

        Stopwatch sw = new Stopwatch();

        public double LastMS
        {
            get { return lastMS; }
        }

        public double AvgMS
        {
            get { return totalMS / (double)count; }
        }

        public Action Do
        {
            set
            {
                if (count > 1000)
                {
                    count = 0;
                    totalMS = 0.0;
                }
                lastMS = 0;
                sw.Start();
                try
                {
                    value();
                }
                finally
                {
                    sw.Stop();
                    lastMS = sw.ElapsedMilliseconds;
                    totalMS += lastMS;
                    count++;
                    sw.Reset();
                }
            }
        }

        [Conditional("DEBUG")]
        public void WriteToDebug()
        {
            Debug.WriteLine(GetInfo());
        }

        public void WriteToConsole()
        {
            Console.WriteLine(GetInfo());
        }

        public void WriteToTrace(int id, string msg)
        {
            var source = new TraceSource(id + " Becnhmark");
            source.TraceInformation("Last: {0} ms, Avg: {1} ms", LastMS, AvgMS);
        }

        private string GetInfo()
        {
            return string.Format("{0} Bechmark - Last: {1} ms, Avg: {2} ms", id, LastMS, AvgMS);
        }
    }
}
