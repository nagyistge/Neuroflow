﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NeoComp.Core;
using System.Diagnostics.Contracts;
using NeoComp.Computations;
using System.Diagnostics;
using System.Runtime.Serialization;
using System.Linq.Expressions;

namespace NeoComp.Networks.Computational
{
    [Serializable]
    [DataContract(IsReference = true, Namespace = NeoComp.xmlns)]
    public abstract class ComputationalConnection<T>
    {
        [DataMember(Name = "value", EmitDefaultValue = false)]
        internal ComputationValue<T> ConnectionValue { get; private set; }

        public T InputValue
        {
            get { return ConnectionValue.Value; }
        }

        public virtual T OutputValue
        {
            get { return InputValue; }
        }

        public virtual Expression OutputValueExpression
        {
            get { return ConnectionValue.ValueExpression; }
        }

        internal void AdaptValue(ComputationValue<T> value)
        {
            Contract.Requires(value != null);

            ConnectionValue = value;
        }

        protected internal virtual void InitializeContext(ComputationalNetwork<T> network, ConnectionEntry<ComputationalConnection<T>>[] inputConnectionEntries, ConnectionEntry<ComputationalConnection<T>>[] outputConnectionEntries) { }
    }
}
