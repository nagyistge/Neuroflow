﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NeoComp.Computations;
using System.Diagnostics.Contracts;
using NeoComp.Core;
using System.Runtime.Serialization;

namespace NeoComp.Networks.Computational
{
    [Serializable]
    [DataContract(IsReference = true, Namespace = NeoComp.xmlns, Name = "valIntf")]
    public sealed class ValueComputationalNetworkInterface<T> : ValueInterface<T>, INetworkInterface<T>
        where T : struct
    {
        internal ValueComputationalNetworkInterface(ComputationValue<T>[] values, SyncContext syncRoot)
            : base(values, syncRoot)
        {
            Contract.Requires(values != null);
            Contract.Requires(values.Length > 0);
            Contract.Requires(syncRoot != null);
        }

        ComputationValue<T> INetworkInterface<T>.GetComputationalValue(int index)
        {
            return Values[index];
        }

        void INetworkInterface<T>.SetValueAt(int index, T value)
        {
            Values[index].Value = value;
        }
    }
}
