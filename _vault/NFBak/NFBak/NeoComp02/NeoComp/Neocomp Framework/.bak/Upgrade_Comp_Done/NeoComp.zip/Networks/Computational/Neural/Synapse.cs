﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NeoComp.Core;
using System.Runtime.Serialization;
using NeoComp.Computations;
using System.Linq.Expressions;

namespace NeoComp.Networks.Computational.Neural
{
    [Serializable]
    [DataContract(IsReference = true, Namespace = NeoComp.xmlns, Name = "synapse")]
    public class Synapse : ComputationalConnection<double>, IBackwardConnection, ILearningConnection
    {
        public Synapse(params ILearningRule[] learningRules)
        {
            if (learningRules != null)
            {
                var fa = learningRules.ToArray();
                if (fa.Length != 0) this.learningRules = ReadOnlyArray.Wrap(fa);
            }
        }

        [DataMember(Name = "weight")]
        ComputationValue<double> weightValue;

        public double Weight
        {
            get { return weightValue.Value; }
            set { weightValue.Value = value; }
        }

        public override double OutputValue
        {
            get { return InputValue * Weight; }
        }

        public override Expression OutputValueExpression
        {
            get { return Expression.Multiply(base.OutputValueExpression, weightValue.ValueExpression); }
        }

        [NonSerialized]
        ReadOnlyArray<ILearningRule> learningRules;

        public ReadOnlyArray<ILearningRule> LearningRules
        {
            get { return learningRules; }
        }

        [NonSerialized]
        BackwardValues backwardValues = new BackwardValues();

        BackwardValues IBackwardConnection.BackwardValues
        {
            get { return backwardValues; }
        }

        IEnumerable<ILearningRule> ILearningConnection.LearningRules
        {
            get { return LearningRules; }
        }

        protected internal override void InitializeContext(ComputationalNetwork<double> network, ConnectionEntry<ComputationalConnection<double>>[] inputConnectionEntries, ConnectionEntry<ComputationalConnection<double>>[] outputConnectionEntries)
        {
            weightValue = network.ValueBuffer.Declare();
        }
    }
}
