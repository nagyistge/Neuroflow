﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Linq.Expressions;

namespace NeoComp.Networks.Computational
{
    [Serializable]
    [DataContract(IsReference = true, Namespace = NeoComp.xmlns)]
    public abstract class ComputationalNode<T>
    {
        protected internal virtual Expression GetExpression(ConnectionEntry<ComputationalConnection<T>>[] inputConnectionEntries, ConnectionEntry<ComputationalConnection<T>>[] outputConnectionEntries)
        {
            return null;
        }
        
        protected internal abstract void Computation(ConnectionEntry<ComputationalConnection<T>>[] inputConnectionEntries, ConnectionEntry<ComputationalConnection<T>>[] outputConnectionEntries);

        protected internal virtual void InitializeContext(ComputationalNetwork<T> network, ConnectionEntry<ComputationalConnection<T>>[] inputConnectionEntries, ConnectionEntry<ComputationalConnection<T>>[] outputConnectionEntries)
        {
            foreach (var ie in inputConnectionEntries) ie.Connection.InitializeContext(network, inputConnectionEntries, outputConnectionEntries);
            foreach (var oe in outputConnectionEntries) oe.Connection.InitializeContext(network, inputConnectionEntries, outputConnectionEntries);
        }
    }
}
