﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Linq.Expressions;

namespace NeoComp.Networks.Computational.Neural
{
    public interface IActivationFunction
    {
        double Function(double value);

        double Derivate(double value);

        double Alpha { get; set; }
    }

    public interface IActivationExpression : IActivationFunction
    {
        Expression FunctionExp(Expression value);

        Expression DerivateExp(Expression value);
    }
}
